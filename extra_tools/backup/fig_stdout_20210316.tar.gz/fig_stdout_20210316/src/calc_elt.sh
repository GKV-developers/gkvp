#!/bin/sh

tail -n 80 ../log/*.000000.0.log.001 > wrk.txt

awk '
  {
    rows[NR]=$0
  }
  END{
    for (i= 3;i<=14;i++){print rows[ i] >> "elt_coarse.dat"}

    for (i= 6;i<= 7;i++){print rows[ i] >> "elt_medium.dat"}
    for (i=18;i<=35;i++){print rows[ i] >> "elt_medium.dat"}
    for (i=72;i<=79;i++){print rows[ i] >> "elt_medium.dat"}
                         print rows[14] >> "elt_medium.dat"

    for (i= 6;i<= 7;i++){print rows[ i] >> "elt_fine.dat"}
    for (i=18;i<=20;i++){print rows[ i] >> "elt_fine.dat"}
    for (i=39;i<=47;i++){print rows[ i] >> "elt_fine.dat"}
    for (i=22;i<=24;i++){print rows[ i] >> "elt_fine.dat"}
    for (i=48;i<=59;i++){print rows[ i] >> "elt_fine.dat"}
                         print rows[29] >> "elt_fine.dat"
    for (i=60;i<=62;i++){print rows[ i] >> "elt_fine.dat"}
                         print rows[31] >> "elt_fine.dat"
    for (i=63;i<=65;i++){print rows[ i] >> "elt_fine.dat"}
    for (i=33;i<=34;i++){print rows[ i] >> "elt_fine.dat"}
    for (i=66;i<=68;i++){print rows[ i] >> "elt_fine.dat"}
    for (i=72;i<=79;i++){print rows[ i] >> "elt_fine.dat"}
                         print rows[14] >> "elt_fine.dat"
  }' wrk.txt

mv *.dat ./data

rm wrk.txt

