#!/bin/bash
#set -Ceu  # Debug option
#set -x   # Show execution
#set +x   # Hide execution


if [ $# -gt 0 ]; then
  if [ $1 == "clean" ]; then
    rm -f ./data/* ./eps/* ./pdf/fig.pdf ./pdf/parameters.tex ./pdf/log.tex ./pdf/graphics.tex ./src/wk_*.gn ./wk.txt
    exit
  fi
fi


#### Explicit use of gnuplot 5, if required ###
#shopt -s expand_aliases
#alias gnuplot='/home/hp150279/u00165/mylib/gnuplot-5.2.8/bin/gnuplot'
#alias gnuplot="/usr/local/gnuplot/5.0.1/bin/gnuplot"
#alias gnuplot="/system/apps/rhel7/lx/gnuplot/5.2.7/bin/gnuplot"
#gnuplot

#### Module setting for ITO-A @ Kyushu Univ.
#module use /home/exp/modulefiles
#module load exp-texlive/2020




#### parameter setting ###
nprocs=`grep 'nprocs' ../log/gkvp.000000.0.log.001 | awk '{print $5}'`
global_ny=`grep 'global_ny = ' ../log/gkvp.000000.0.log.001 | awk '{print $4}'`
calc_type=`grep 'Type of calc' ../log/gkvp.000000.0.log.001 | awk '{print $6}'`
#echo $nprocs $global_ny $calc_type
nprocs=`echo ${nprocs} | sed -e 's/,$//'`


#### rearrange for plots ###
rm -f ./data/*.dat
./src/calc_elt.sh
cat ../hst/gkvp.mtr.001 > ./data/mtr.dat
cat ../hst/gkvp.dtc.* > ./data/dtc.dat
cat ../hst/gkvp.eng.* > ./data/eng.dat
cat ../hst/gkvp.men.* > ./data/men.dat
cat ../hst/gkvp.wes.* > ./data/wes.dat
cat ../hst/gkvp.wem.* > ./data/wem.dat
i=0
while [ $i -lt $nprocs ]; do
  cat ../hst/gkvp.ges.$i.* > ./data/ges.$i.dat
  cat ../hst/gkvp.gem.$i.* > ./data/gem.$i.dat
  cat ../hst/gkvp.qes.$i.* > ./data/qes.$i.dat
  cat ../hst/gkvp.qem.$i.* > ./data/qem.$i.dat
  cat ../hst/gkvp.bln.$i.* > ./data/bln.$i.dat
  gawk -f ./src/calc_entropybalance.awk ./data/bln.$i.dat > ./data/ent.$i.dat
  i=$(( $i + 1 ))
done
if [ $calc_type != "nonlinear" ]; then
  cat ../hst/gkvp.frq.* > ./data/frq.dat
  cat `find ../hst/*.dsp.* -size +0k | awk 'END{print $1}'` > ./data/dsp.dat
fi


#### plots ###
gnuplot ./src/plot_elt.gn        # Histogram of elapsed time
gnuplot ./src/plot_zmtr.gn       # Metric data along field line
gnuplot ./src/plot_tdtc.gn       # Time evolution of time step size dt

cat ./src/plot_teng.gn | sed -e "s/global_ny = 999/global_ny =$global_ny/g" > ./src/wk_teng.gn
cat ./src/plot_tmen.gn | sed -e "s/global_ny = 999/global_ny =$global_ny/g" > ./src/wk_tmen.gn
cat ./src/plot_twes.gn | sed -e "s/global_ny = 999/global_ny =$global_ny/g" > ./src/wk_twes.gn
cat ./src/plot_twem.gn | sed -e "s/global_ny = 999/global_ny =$global_ny/g" > ./src/wk_twem.gn
gnuplot ./src/wk_teng.gn         # Time evolution of electrostatic potential |phi|^2
gnuplot ./src/wk_twes.gn         # Time evolution of electrostatic energy W_E
if [ $nprocs -gt 1 ]; then
  gnuplot ./src/wk_tmen.gn       # Time evolution of vector potential |Al|^2
  gnuplot ./src/wk_twem.gn       # Time evolution of magnetic field energy W_M
fi
rm ./src/wk_teng.gn ./src/wk_tmen.gn ./src/wk_twes.gn ./src/wk_twem.gn
i=0
while [ $i -lt $nprocs ]; do
  cat ./src/plot_tges.s.gn    | sed -e "s/global_ny = 999/global_ny =$global_ny/g" \
                              | sed -e "s/ranks = 999/ranks = $i/g" > ./src/wk_tges.$i.gn
  cat ./src/plot_tgem.s.gn    | sed -e "s/global_ny = 999/global_ny =$global_ny/g" \
                              | sed -e "s/ranks = 999/ranks = $i/g" > ./src/wk_tgem.$i.gn
  cat ./src/plot_tqes.s.gn    | sed -e "s/global_ny = 999/global_ny =$global_ny/g" \
                              | sed -e "s/ranks = 999/ranks = $i/g" > ./src/wk_tqes.$i.gn
  cat ./src/plot_tqem.s.gn    | sed -e "s/global_ny = 999/global_ny =$global_ny/g" \
                              | sed -e "s/ranks = 999/ranks = $i/g" > ./src/wk_tqem.$i.gn
  cat ./src/plot_tent.s.gn    | sed -e "s/ranks = 999/ranks = $i/g" > ./src/wk_tent.$i.gn
  cat ./src/plot_tent.s.zf.gn | sed -e "s/ranks = 999/ranks = $i/g" > ./src/wk_tent.$i.zf.gn
  cat ./src/plot_tent.s.nz.gn | sed -e "s/ranks = 999/ranks = $i/g" > ./src/wk_tent.$i.nz.gn
  gnuplot ./src/wk_tges.$i.gn    # Time evolution of particle flux G_sE for ranks = $i
  gnuplot ./src/wk_tgem.$i.gn    # Time evolution of particle flux G_sM for ranks = $i
  gnuplot ./src/wk_tqes.$i.gn    # Time evolution of energy flux Q_sE for ranks = $i
  gnuplot ./src/wk_tqem.$i.gn    # Time evolution of energy flux Q_sM for ranks = $i
  gnuplot ./src/wk_tent.$i.gn    # Time evolution of entropy balance for ranks = $i
  gnuplot ./src/wk_tent.$i.zf.gn # Time evolution of entropy balance for ranks = $i (ky==0)
  gnuplot ./src/wk_tent.$i.nz.gn # Time evolution of entropy balance for ranks = $i (ky/=0)
  rm ./src/wk_tges.$i.gn ./src/wk_tgem.$i.gn ./src/wk_tqes.$i.gn ./src/wk_tqem.$i.gn \
     ./src/wk_tent.$i.gn ./src/wk_tent.$i.zf.gn ./src/wk_tent.$i.nz.gn
  i=$(( $i + 1 ))
done
cat ./src/plot_teint.gn    | sed -e "s/nprocs = 999/nprocs =$nprocs/g" > ./src/wk_teint.gn
cat ./src/plot_teint.zf.gn | sed -e "s/nprocs = 999/nprocs =$nprocs/g" > ./src/wk_teint.zf.gn
cat ./src/plot_teint.nz.gn | sed -e "s/nprocs = 999/nprocs =$nprocs/g" > ./src/wk_teint.nz.gn
cat ./src/plot_tmint.gn    | sed -e "s/nprocs = 999/nprocs =$nprocs/g" > ./src/wk_tmint.gn
cat ./src/plot_tmint.zf.gn | sed -e "s/nprocs = 999/nprocs =$nprocs/g" > ./src/wk_tmint.zf.gn
cat ./src/plot_tmint.nz.gn | sed -e "s/nprocs = 999/nprocs =$nprocs/g" > ./src/wk_tmint.nz.gn
gnuplot ./src/wk_teint.gn        # Time evolution of entropy balance for electric field
gnuplot ./src/wk_teint.zf.gn     # Time evolution of entropy balance for electric field ( ky = 0 )
gnuplot ./src/wk_teint.nz.gn     # Time evolution of entropy balance for electric field ( ky /= 0 )
gnuplot ./src/wk_tmint.gn        # Time evolution of entropy balance for magnetic field
gnuplot ./src/wk_tmint.zf.gn     # Time evolution of entropy balance for magnetic field ( ky = 0 )
gnuplot ./src/wk_tmint.nz.gn     # Time evolution of entropy balance for magnetic field ( ky /= 0 )
rm ./src/wk_teint.gn ./src/wk_teint.zf.gn ./src/wk_teint.nz.gn \
   ./src/wk_tmint.gn ./src/wk_tmint.zf.gn ./src/wk_tmint.nz.gn   
if [ $calc_type != "nonlinear" ]; then
  cat ./src/plot_tfreq.gn | sed -e "s/global_ny = 999/global_ny =$global_ny/g" > ./src/wk_tfreq.gn
  cat ./src/plot_tgrow.gn | sed -e "s/global_ny = 999/global_ny =$global_ny/g" > ./src/wk_tgrow.gn
  gnuplot ./src/wk_tfreq.gn      # ( For linear runs ) Frequency  in time ( kx = 0 )
  gnuplot ./src/wk_tgrow.gn      # ( For linear runs ) Growthrate in time ( kx = 0 )
  gnuplot ./src/plot_kfreq.gn    # ( For linear runs ) Frequency  as a function of ky ( kx = 0 )
  gnuplot ./src/plot_kgrow.gn    # ( For linear runs ) Growthrate as a function of ky ( kx = 0 )
  gnuplot ./src/plot_kxkyfreq.gn # ( For linear runs ) Frequency as a function of (kx,ky)
  gnuplot ./src/plot_kxkygrow.gn # ( For linear runs ) Frequency as a function of (kx,ky)
  rm ./src/wk_tfreq.gn ./src/wk_tgrow.gn
fi


### pdf ###
echo `pwd`'\\\\' | sed -e 's/_/\\_/g' >> parameters.tex
echo `date`'\\\\' >> parameters.tex
cat ../gkvp_namelist.001 | sed -e 's/&cmemo/\\underline{cmemo}\\\\/g' \
                         | sed -e 's/&calct/\\underline{calct}\\\\/g' \
                         | sed -e 's/&triad/\\underline{triad}\\\\/g' \
                         | sed -e 's/&equib/\\underline{equib}\\\\/g' \
                         | sed -e 's/&run_n/\\underline{run_n}\\\\/g' \
                         | sed -e 's/&files/\\underline{files}\\\\/g' \
                         | sed -e 's/&runlm/\\underline{runlm}\\\\/g' \
                         | sed -e 's/&times/\\underline{times}\\\\/g' \
                         | sed -e 's/&deltt/\\underline{deltt}\\\\/g' \
                         | sed -e 's/&physp/\\underline{physp}\\\\/g' \
                         | sed -e 's/&rotat/\\underline{rotat}\\\\/g' \
                         | sed -e 's/&nperi/\\underline{nperi}\\\\/g' \
                         | sed -e 's/&confp/\\underline{confp}\\\\/g' \
                         | sed -e 's/&vmecp/\\underline{vmecp}\\\\/g' \
                         | sed -e 's/&bozxf/\\underline{bozxf}\\\\/g' \
                         | sed -e 's/&igsp/\\underline{igsp}\\\\/g' \
                         | sed -e 's/&igsf/\\underline{igsf}\\\\/g' \
                         | sed -e 's/&nu_ref/\\underline{nu_ref}\\\\/g' \
                         | sed -e 's/&end//g' \
                         | sed -e 's/_/\\_/g' \
                         | sed -e 's/$/\\\\/g' >> parameters.tex

echo "#" > wk.txt
sed -n '/nxw, nyw  =/p'            ../log/gkvp.000000.0.log.001 >> wk.txt
sed -n '/global_ny =/p'            ../log/gkvp.000000.0.log.001 >> wk.txt
sed -n '/global_nz =/p'            ../log/gkvp.000000.0.log.001 >> wk.txt
sed -n '/global_nv, global_nm =/p' ../log/gkvp.000000.0.log.001 >> wk.txt
sed -n '/nx, ny, nz   =/p'         ../log/gkvp.000000.0.log.001 >> wk.txt
sed -n '/nv, nm       =/p'         ../log/gkvp.000000.0.log.001 >> wk.txt
sed -n '/nzb, nvb     =/p'         ../log/gkvp.000000.0.log.001 >> wk.txt
sed -n '/number of species  =/p'   ../log/gkvp.000000.0.log.001 >> wk.txt
sed -n '/nproc/p'                  ../log/gkvp.000000.0.log.001 >> wk.txt
echo "#" >> wk.txt
sed -n '/q_0          =/p' ../log/gkvp.000000.0.log.001 >> wk.txt 
sed -n '/s_hat        =/p' ../log/gkvp.000000.0.log.001 >> wk.txt
sed -n '/eps_r        =/p' ../log/gkvp.000000.0.log.001 >> wk.txt
sed -n '/s_input, s_0 =/p' ../log/gkvp.000000.0.log.001 >> wk.txt
sed -n '/nss, ntheta  =/p' ../log/gkvp.000000.0.log.001 >> wk.txt
echo "#" >> wk.txt
sed -n '/lx, ly, lz   =/p'   ../log/gkvp.000000.0.log.001 >> wk.txt
sed -n '/lz,   z0     =/p'   ../log/gkvp.000000.0.log.001 >> wk.txt
sed -n '/lz_l, z0_l   =/p'   ../log/gkvp.000000.0.log.001 >> wk.txt
sed -n '/kxmin, kymin =/p'   ../log/gkvp.000000.0.log.001 >> wk.txt
sed -n '/kxmax, kymax =/p'   ../log/gkvp.000000.0.log.001 >> wk.txt
sed -n '/kperp_max    =/p'   ../log/gkvp.000000.0.log.001 >> wk.txt
sed -n '/m_j, del_c   =/p'   ../log/gkvp.000000.0.log.001 >> wk.txt
sed -n '/dz           =/p'   ../log/gkvp.000000.0.log.001 >> wk.txt
sed -n '/dv, vmax     =/p'   ../log/gkvp.000000.0.log.001 >> wk.txt
sed -n '/dm, mmax     =/p'   ../log/gkvp.000000.0.log.001 >> wk.txt
echo "#" >> wk.txt
sed -n '/time_advnc   =/p'   ../log/gkvp.000000.0.log.001 >> wk.txt
sed -n '/flag_time_adv=/p'   ../log/gkvp.000000.0.log.001 >> wk.txt
sed -n '/courant num. =/p'   ../log/gkvp.000000.0.log.001 >> wk.txt
sed -n '/dt_perp      =/p'   ../log/gkvp.000000.0.log.001 >> wk.txt
sed -n '/dt_zz        =/p'   ../log/gkvp.000000.0.log.001 >> wk.txt
sed -n '/dt_vl        =/p'   ../log/gkvp.000000.0.log.001 >> wk.txt
sed -n '/dt_col       =/p'   ../log/gkvp.000000.0.log.001 >> wk.txt
sed -n '/dt_linear    =/p'   ../log/gkvp.000000.0.log.001 >> wk.txt
sed -n '/dt_max       =/p'   ../log/gkvp.000000.0.log.001 >> wk.txt
sed -n '/dt           =/p'   ../log/gkvp.000000.0.log.001 >> wk.txt
echo "#" >> wk.txt
sed -n '/a, b, nu*_ab =/p'   ../log/gkvp.000000.0.log.001 >> wk.txt
 
cat wk.txt | sed -e 's/_/\\_/g' | sed -e 's/#/\\#/g' | sed -e 's/$/\\\\/g' > log.tex
rm wk.txt

echo ""                                         > graphics.tex
echo "\\begin{figure}[!ht]"                    >> graphics.tex
echo "\\includegraphics[]{elt_coarse.eps}\\\\" >> graphics.tex
echo "\\includegraphics[]{elt_medium.eps}\\\\" >> graphics.tex
echo "\\includegraphics[]{elt_fine.eps}"       >> graphics.tex
echo "\\end{figure}"                           >> graphics.tex
echo ""                                        >> graphics.tex
echo "\\begin{figure}[!ht]"                    >> graphics.tex
echo "\\includegraphics[]{bb.eps}"             >> graphics.tex
echo "\\includegraphics[]{dbdx.eps}\\\\"       >> graphics.tex
echo "\\includegraphics[]{dbdy.eps}"           >> graphics.tex
echo "\\includegraphics[]{dbdz.eps}\\\\"       >> graphics.tex
echo "\\includegraphics[]{gxx.eps}"            >> graphics.tex
echo "\\includegraphics[]{gxy.eps}\\\\"        >> graphics.tex
echo "\\includegraphics[]{gxz.eps}"            >> graphics.tex
echo "\\includegraphics[]{gyy.eps}\\\\"        >> graphics.tex
echo "\\includegraphics[]{gyz.eps}"            >> graphics.tex
echo "\\includegraphics[]{gzz.eps}\\\\"        >> graphics.tex
echo "\\includegraphics[]{jacobian.eps}"       >> graphics.tex
echo "\\end{figure}"                           >> graphics.tex
echo ""                                        >> graphics.tex
if [ $calc_type != "nonlinear" ]; then
  echo "\\begin{figure}[!ht]"                  >> graphics.tex
  echo "\\includegraphics[]{tgrow.eps}"        >> graphics.tex
  echo "\\includegraphics[]{tfreq.eps}\\\\"    >> graphics.tex
  echo "\\includegraphics[]{kgrow.eps}"        >> graphics.tex
  echo "\\includegraphics[]{kfreq.eps}"        >> graphics.tex
  echo "\\end{figure}"                         >> graphics.tex
  echo ""                                      >> graphics.tex
fi
echo "\\begin{figure}[!ht]"                    >> graphics.tex
echo "\\includegraphics[]{tdtc.eps}\\\\"       >> graphics.tex
echo "\\includegraphics[]{teng.eps}\\\\"       >> graphics.tex
if [ $nprocs -gt 1 ]; then
  echo "\\includegraphics[]{tmen.eps}"         >> graphics.tex
fi
echo "\\end{figure}"                           >> graphics.tex
echo ""                                        >> graphics.tex
i=0
while [ $i -lt $nprocs ]; do
  echo "\\begin{figure}[!ht]"                  >> graphics.tex
  echo "\\includegraphics[]{tent.$i.eps}\\\\"  >> graphics.tex
  echo "\\includegraphics[]{tges.$i.eps}"      >> graphics.tex
  echo "\\includegraphics[]{tgem.$i.eps}\\\\"  >> graphics.tex
  echo "\\includegraphics[]{tqes.$i.eps}"      >> graphics.tex
  echo "\\includegraphics[]{tqem.$i.eps}"      >> graphics.tex
  echo "\\end{figure}"                         >> graphics.tex
  echo ""                                      >> graphics.tex
  i=$(( $i + 1 ))
done
echo "\\begin{figure}[!ht]"                    >> graphics.tex
echo "\\includegraphics[]{teint.eps}"          >> graphics.tex
echo "\\includegraphics[]{tmint.eps}\\\\"      >> graphics.tex
echo "\\includegraphics[]{twes.eps}"           >> graphics.tex
if [ $nprocs -gt 1 ]; then
  echo "\\includegraphics[]{twem.eps}"         >> graphics.tex
fi
echo "\\end{figure}"                           >> graphics.tex
echo ""                                        >> graphics.tex

mv parameters.tex pdf/
mv log.tex pdf/
mv graphics.tex pdf/
cp ./eps/*.eps ./pdf/
cd ./pdf/
latex fig.tex
dvipdf -sPAPERSIZE=a4 fig.dvi
rm fig.aux fig.log fig.dvi
rm *.eps
##gv fig.pdf
##evince fig.pdf
